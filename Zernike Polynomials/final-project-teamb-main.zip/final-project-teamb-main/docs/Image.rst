Image module
============

.. automodule:: Image
   :members:
   :undoc-members:
   :show-inheritance:
