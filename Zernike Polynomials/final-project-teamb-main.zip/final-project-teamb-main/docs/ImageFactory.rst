ImageFactory module
===================

.. automodule:: ImageFactory
   :members:
   :undoc-members:
   :show-inheritance:
